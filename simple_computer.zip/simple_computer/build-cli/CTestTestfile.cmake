# CMake generated Testfile for 
# Source directory: D:/QTwork/simple_computer
# Build directory: D:/QTwork/simple_computer/build-cli
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test(simple_computor "D:/QTwork/simple_computer/build-cli/tst_simple_computor.exe")
set_tests_properties(simple_computor PROPERTIES  ENVIRONMENT "QT_QPA_PLATFORM=offscreen" _BACKTRACE_TRIPLES "D:/QTwork/simple_computer/CMakeLists.txt;99;add_test;D:/QTwork/simple_computer/CMakeLists.txt;0;")
