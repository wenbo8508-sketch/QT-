# Additional clean files
cmake_minimum_required(VERSION 3.16)

if("${CONFIG}" STREQUAL "" OR "${CONFIG}" STREQUAL "Debug")
  file(REMOVE_RECURSE
  "CMakeFiles\\simple_computor_autogen.dir\\AutogenUsed.txt"
  "CMakeFiles\\simple_computor_autogen.dir\\ParseCache.txt"
  "CMakeFiles\\tst_simple_computor_autogen.dir\\AutogenUsed.txt"
  "CMakeFiles\\tst_simple_computor_autogen.dir\\ParseCache.txt"
  "simple_computor_autogen"
  "tst_simple_computor_autogen"
  )
endif()
