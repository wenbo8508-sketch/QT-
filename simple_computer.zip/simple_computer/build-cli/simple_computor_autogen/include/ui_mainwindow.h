/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.11.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QVBoxLayout *verticalLayout;
    QGridLayout *gridLayout_2;
    QPushButton *multiple;
    QPushButton *num5;
    QPushButton *num2;
    QPushButton *present;
    QPushButton *del;
    QPushButton *addition;
    QPushButton *num7;
    QPushButton *divite;
    QPushButton *num3;
    QPushButton *subtraction;
    QPushButton *num9;
    QPushButton *fraction;
    QPushButton *CE;
    QPushButton *point;
    QPushButton *num6;
    QPushButton *num0;
    QPushButton *zhengfu;
    QPushButton *num1;
    QPushButton *root;
    QPushButton *num8;
    QPushButton *num4;
    QPushButton *sum;
    QPushButton *C;
    QPushButton *square;
    QLineEdit *display;
    QLabel *hintLabel;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->resize(338, 360);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName("centralwidget");
        verticalLayout = new QVBoxLayout(centralwidget);
        verticalLayout->setObjectName("verticalLayout");
        verticalLayout->setContentsMargins(11, 11, -1, -1);
        gridLayout_2 = new QGridLayout();
        gridLayout_2->setObjectName("gridLayout_2");
        multiple = new QPushButton(centralwidget);
        multiple->setObjectName("multiple");
        QSizePolicy sizePolicy(QSizePolicy::Policy::Minimum, QSizePolicy::Policy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(multiple->sizePolicy().hasHeightForWidth());
        multiple->setSizePolicy(sizePolicy);

        gridLayout_2->addWidget(multiple, 3, 3, 1, 1);

        num5 = new QPushButton(centralwidget);
        num5->setObjectName("num5");
        sizePolicy.setHeightForWidth(num5->sizePolicy().hasHeightForWidth());
        num5->setSizePolicy(sizePolicy);

        gridLayout_2->addWidget(num5, 4, 1, 1, 1);

        num2 = new QPushButton(centralwidget);
        num2->setObjectName("num2");
        sizePolicy.setHeightForWidth(num2->sizePolicy().hasHeightForWidth());
        num2->setSizePolicy(sizePolicy);

        gridLayout_2->addWidget(num2, 5, 1, 1, 1);

        present = new QPushButton(centralwidget);
        present->setObjectName("present");
        sizePolicy.setHeightForWidth(present->sizePolicy().hasHeightForWidth());
        present->setSizePolicy(sizePolicy);

        gridLayout_2->addWidget(present, 1, 0, 1, 1);

        del = new QPushButton(centralwidget);
        del->setObjectName("del");
        sizePolicy.setHeightForWidth(del->sizePolicy().hasHeightForWidth());
        del->setSizePolicy(sizePolicy);

        gridLayout_2->addWidget(del, 1, 3, 1, 1);

        addition = new QPushButton(centralwidget);
        addition->setObjectName("addition");
        sizePolicy.setHeightForWidth(addition->sizePolicy().hasHeightForWidth());
        addition->setSizePolicy(sizePolicy);

        gridLayout_2->addWidget(addition, 5, 3, 1, 1);

        num7 = new QPushButton(centralwidget);
        num7->setObjectName("num7");
        sizePolicy.setHeightForWidth(num7->sizePolicy().hasHeightForWidth());
        num7->setSizePolicy(sizePolicy);

        gridLayout_2->addWidget(num7, 3, 0, 1, 1);

        divite = new QPushButton(centralwidget);
        divite->setObjectName("divite");
        sizePolicy.setHeightForWidth(divite->sizePolicy().hasHeightForWidth());
        divite->setSizePolicy(sizePolicy);

        gridLayout_2->addWidget(divite, 2, 3, 1, 1);

        num3 = new QPushButton(centralwidget);
        num3->setObjectName("num3");
        sizePolicy.setHeightForWidth(num3->sizePolicy().hasHeightForWidth());
        num3->setSizePolicy(sizePolicy);

        gridLayout_2->addWidget(num3, 5, 2, 1, 1);

        subtraction = new QPushButton(centralwidget);
        subtraction->setObjectName("subtraction");
        sizePolicy.setHeightForWidth(subtraction->sizePolicy().hasHeightForWidth());
        subtraction->setSizePolicy(sizePolicy);

        gridLayout_2->addWidget(subtraction, 4, 3, 1, 1);

        num9 = new QPushButton(centralwidget);
        num9->setObjectName("num9");
        sizePolicy.setHeightForWidth(num9->sizePolicy().hasHeightForWidth());
        num9->setSizePolicy(sizePolicy);

        gridLayout_2->addWidget(num9, 3, 2, 1, 1);

        fraction = new QPushButton(centralwidget);
        fraction->setObjectName("fraction");
        sizePolicy.setHeightForWidth(fraction->sizePolicy().hasHeightForWidth());
        fraction->setSizePolicy(sizePolicy);

        gridLayout_2->addWidget(fraction, 2, 0, 1, 1);

        CE = new QPushButton(centralwidget);
        CE->setObjectName("CE");
        sizePolicy.setHeightForWidth(CE->sizePolicy().hasHeightForWidth());
        CE->setSizePolicy(sizePolicy);

        gridLayout_2->addWidget(CE, 1, 1, 1, 1);

        point = new QPushButton(centralwidget);
        point->setObjectName("point");
        sizePolicy.setHeightForWidth(point->sizePolicy().hasHeightForWidth());
        point->setSizePolicy(sizePolicy);

        gridLayout_2->addWidget(point, 6, 2, 1, 1);

        num6 = new QPushButton(centralwidget);
        num6->setObjectName("num6");
        sizePolicy.setHeightForWidth(num6->sizePolicy().hasHeightForWidth());
        num6->setSizePolicy(sizePolicy);

        gridLayout_2->addWidget(num6, 4, 2, 1, 1);

        num0 = new QPushButton(centralwidget);
        num0->setObjectName("num0");
        sizePolicy.setHeightForWidth(num0->sizePolicy().hasHeightForWidth());
        num0->setSizePolicy(sizePolicy);

        gridLayout_2->addWidget(num0, 6, 1, 1, 1);

        zhengfu = new QPushButton(centralwidget);
        zhengfu->setObjectName("zhengfu");
        sizePolicy.setHeightForWidth(zhengfu->sizePolicy().hasHeightForWidth());
        zhengfu->setSizePolicy(sizePolicy);

        gridLayout_2->addWidget(zhengfu, 6, 0, 1, 1);

        num1 = new QPushButton(centralwidget);
        num1->setObjectName("num1");
        sizePolicy.setHeightForWidth(num1->sizePolicy().hasHeightForWidth());
        num1->setSizePolicy(sizePolicy);

        gridLayout_2->addWidget(num1, 5, 0, 1, 1);

        root = new QPushButton(centralwidget);
        root->setObjectName("root");
        sizePolicy.setHeightForWidth(root->sizePolicy().hasHeightForWidth());
        root->setSizePolicy(sizePolicy);

        gridLayout_2->addWidget(root, 2, 2, 1, 1);

        num8 = new QPushButton(centralwidget);
        num8->setObjectName("num8");
        sizePolicy.setHeightForWidth(num8->sizePolicy().hasHeightForWidth());
        num8->setSizePolicy(sizePolicy);

        gridLayout_2->addWidget(num8, 3, 1, 1, 1);

        num4 = new QPushButton(centralwidget);
        num4->setObjectName("num4");
        sizePolicy.setHeightForWidth(num4->sizePolicy().hasHeightForWidth());
        num4->setSizePolicy(sizePolicy);

        gridLayout_2->addWidget(num4, 4, 0, 1, 1);

        sum = new QPushButton(centralwidget);
        sum->setObjectName("sum");
        sizePolicy.setHeightForWidth(sum->sizePolicy().hasHeightForWidth());
        sum->setSizePolicy(sizePolicy);

        gridLayout_2->addWidget(sum, 6, 3, 1, 1);

        C = new QPushButton(centralwidget);
        C->setObjectName("C");
        sizePolicy.setHeightForWidth(C->sizePolicy().hasHeightForWidth());
        C->setSizePolicy(sizePolicy);

        gridLayout_2->addWidget(C, 1, 2, 1, 1);

        square = new QPushButton(centralwidget);
        square->setObjectName("square");
        sizePolicy.setHeightForWidth(square->sizePolicy().hasHeightForWidth());
        square->setSizePolicy(sizePolicy);

        gridLayout_2->addWidget(square, 2, 1, 1, 1);

        display = new QLineEdit(centralwidget);
        display->setObjectName("display");
        QSizePolicy sizePolicy1(QSizePolicy::Policy::Expanding, QSizePolicy::Policy::Preferred);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(display->sizePolicy().hasHeightForWidth());
        display->setSizePolicy(sizePolicy1);
        display->setAlignment(Qt::AlignmentFlag::AlignRight|Qt::AlignmentFlag::AlignTrailing|Qt::AlignmentFlag::AlignVCenter);

        gridLayout_2->addWidget(display, 0, 0, 1, 4);


        verticalLayout->addLayout(gridLayout_2);

        hintLabel = new QLabel(centralwidget);
        hintLabel->setObjectName("hintLabel");
        hintLabel->setAlignment(Qt::AlignmentFlag::AlignCenter);
        hintLabel->setWordWrap(true);

        verticalLayout->addWidget(hintLabel);

        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 338, 22));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName("statusbar");
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "\345\270\246\351\224\256\347\233\230\344\272\213\344\273\266\347\232\204\350\256\241\347\256\227\345\231\250", nullptr));
        multiple->setText(QCoreApplication::translate("MainWindow", "\303\227", nullptr));
        num5->setText(QCoreApplication::translate("MainWindow", "5", nullptr));
        num2->setText(QCoreApplication::translate("MainWindow", "2", nullptr));
        present->setText(QCoreApplication::translate("MainWindow", "%", nullptr));
        del->setText(QCoreApplication::translate("MainWindow", "\342\214\253", nullptr));
        addition->setText(QCoreApplication::translate("MainWindow", "+", nullptr));
        num7->setText(QCoreApplication::translate("MainWindow", "7", nullptr));
        divite->setText(QCoreApplication::translate("MainWindow", "/", nullptr));
        num3->setText(QCoreApplication::translate("MainWindow", "3", nullptr));
        subtraction->setText(QCoreApplication::translate("MainWindow", "-", nullptr));
        num9->setText(QCoreApplication::translate("MainWindow", "9", nullptr));
        fraction->setText(QCoreApplication::translate("MainWindow", "1/X", nullptr));
        CE->setText(QCoreApplication::translate("MainWindow", "CE", nullptr));
        point->setText(QCoreApplication::translate("MainWindow", ".", nullptr));
        num6->setText(QCoreApplication::translate("MainWindow", "6", nullptr));
        num0->setText(QCoreApplication::translate("MainWindow", "0", nullptr));
        zhengfu->setText(QCoreApplication::translate("MainWindow", "\302\261", nullptr));
        num1->setText(QCoreApplication::translate("MainWindow", "1", nullptr));
        root->setText(QCoreApplication::translate("MainWindow", "\342\210\232", nullptr));
        num8->setText(QCoreApplication::translate("MainWindow", "8", nullptr));
        num4->setText(QCoreApplication::translate("MainWindow", "4", nullptr));
        sum->setText(QCoreApplication::translate("MainWindow", "=", nullptr));
        C->setText(QCoreApplication::translate("MainWindow", "C", nullptr));
        square->setText(QCoreApplication::translate("MainWindow", "X^2", nullptr));
        display->setPlaceholderText(QCoreApplication::translate("MainWindow", "0", nullptr));
        hintLabel->setText(QCoreApplication::translate("MainWindow", "\351\224\256\347\233\230\357\274\2320-9 . + - * / = %  Enter \350\256\241\347\256\227  Backspace \351\200\200\346\240\274  Delete \346\270\205\351\231\244\350\276\223\345\205\245  Esc \345\205\250\351\203\250\346\270\205\351\231\244  x \344\271\230  ^ \345\271\263\346\226\271  r \345\274\200\346\226\271", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
